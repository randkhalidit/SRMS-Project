import java.util.List;

public class Main {

    public static void main(String[] args) {
        SRMS mySystem = new SRMS();

        List<Student> savedData = StudentFileManager.loadStudents();
        mySystem.getStudents().addAll(savedData);

        AutoSaveThread autoSave = new AutoSaveThread(mySystem);
        autoSave.start();

        System.out.println("--- Student Record Management System Started ---");
        
        mySystem.displayAllStudents();
    }
}

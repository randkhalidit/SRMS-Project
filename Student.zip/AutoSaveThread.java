public class AutoSaveThread extends Thread {
    private SRMS srms;
    private boolean running = true;

    public AutoSaveThread(SRMS srms) {
        this.srms = srms;
    }

    public void stopThread() {
        running = false;
        this.interrupt();
    }

    @Override
    public void run() {
        while (running) {
            try {
                Thread.sleep(30000);
                StudentFileManager.saveStudents(srms.getStudents());
                System.out.println("\n[System] Auto-save completed successfully.");
            } catch (InterruptedException e) {
                if (!running) break;
            }
        }
    }
}
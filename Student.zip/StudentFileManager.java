import java.io.*;
import java.util.ArrayList;
import java.util.List;

/* Data Expert Task: File Management System
   Handles saving and loading student records to/from a text file.
   Integrates with Student class toString() for data formatting. */
public class StudentFileManager {
    private static final String FILE_NAME = "students.txt";

    // Static method to save the student list to a file
    public static void saveStudents(List<Student> students) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (Student s : students) {
                // Uses toString() method designed by The Architect
                writer.write(s.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving students: " + e.getMessage());
        }
    }

    // Static method to load records from the file back into the system
    public static List<Student> loadStudents() {
        List<Student> students = new ArrayList<>();
        File file = new File(FILE_NAME);
        
        if (!file.exists()) return students;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 5) {
                    // Reconstructs Student objects using the Constructor from The Architect
                    students.add(new Student(
                        parts[1], // name
                        parts[0], // id
                        Double.parseDouble(parts[2]), // gpa
                        parts[3], // department
                        Integer.parseInt(parts[4]) // year
                    ));
                }
            }
        } catch (Exception e) {
            System.out.println("Error loading data: " + e.getMessage());
        }
        return students;
    }
}
